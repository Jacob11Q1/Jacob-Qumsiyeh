// ----- Typing Animation ----- //
var typed = new Typed(".typing", {
    strings: ["Full Stack Developer", "Web Designer", "Graphic Designer"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true
});